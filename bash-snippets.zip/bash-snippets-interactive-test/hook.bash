#!/usr/bin/env bash

run_story 'currency/example1'
run_story 'currency/example2'
