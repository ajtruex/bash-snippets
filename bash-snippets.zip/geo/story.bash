#!/bin/bash

bash $story_dir/geo $(cli_args)


