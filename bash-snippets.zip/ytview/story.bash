#!/bin/bash

bash $story_dir/ytview $(cli_args)


