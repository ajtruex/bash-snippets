#!/bin/bash

bash $story_dir/short $(cli_args)


