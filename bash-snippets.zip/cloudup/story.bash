#!/bin/bash

bash $story_dir/cloudup $(cli_args)


