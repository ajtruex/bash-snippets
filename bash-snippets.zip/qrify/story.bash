#!/bin/bash

bash $story_dir/qrify $(cli_args)


