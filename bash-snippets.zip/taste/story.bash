#!/bin/bash

bash $story_dir/taste $(cli_args)


