#!/bin/bash

bash $story_dir/currency $(cli_args)


