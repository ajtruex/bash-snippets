#!/bin/bash

bash $story_dir/weather $(cli_args)


