#!/bin/bash

bash $story_dir/crypt $(cli_args)


