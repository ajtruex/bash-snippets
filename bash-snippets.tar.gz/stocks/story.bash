#!/bin/bash

bash $story_dir/stocks $(cli_args)


