# SYNOPSIS

Run tests against BashSnippets tools with interactive prompt.

# INSTALL

    $ sparrow plg install bash-snippets-interactive-test

# USAGE

    $ sparrow plg run bash-snippets-interactive-test --param dir=/path/to/bash-snippets/tools/directory


![report](https://raw.githubusercontent.com/melezhik/images/master/report.png)

# Authors

* The plugin maintainer is [Alexey Melezhik](https://github.com/melezhik/)



