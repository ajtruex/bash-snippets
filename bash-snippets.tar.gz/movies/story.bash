#!/bin/bash

bash $story_dir/movies $(cli_args)


